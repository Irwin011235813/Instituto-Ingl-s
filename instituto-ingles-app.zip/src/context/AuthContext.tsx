import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '@/services/firebase';
import type { UsuarioAutorizado } from '@/modules/usuarios/types';

interface AuthContextValue {
  usuarioFirebase: User | null;
  perfil: UsuarioAutorizado | null;
  cargando: boolean;
  error: string | null;
  iniciarSesionConGoogle: () => Promise<void>;
  cerrarSesion: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [usuarioFirebase, setUsuarioFirebase] = useState<User | null>(null);
  const [perfil, setPerfil] = useState<UsuarioAutorizado | null>(null);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCargando(true);
      setUsuarioFirebase(user);

      if (!user) {
        setPerfil(null);
        setCargando(false);
        return;
      }

      try {
        const ref = doc(db, 'usuarios_autorizados', user.uid);
        const snap = await getDoc(ref);

        if (!snap.exists()) {
          setError('Tu cuenta todavía no fue habilitada por un administrador del instituto.');
          setPerfil(null);
        } else {
          const datos = snap.data() as UsuarioAutorizado;
          if (!datos.activo) {
            setError('Tu cuenta fue desactivada. Contactá a un administrador.');
            setPerfil(null);
          } else {
            setPerfil(datos);
            setError(null);
          }
        }
      } catch {
        setError('No se pudo verificar tu perfil. Intentá de nuevo.');
        setPerfil(null);
      } finally {
        setCargando(false);
      }
    });

    return unsubscribe;
  }, []);

  async function iniciarSesionConGoogle() {
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch {
      setError('No se pudo iniciar sesión con Google. Intentá de nuevo.');
    }
  }

  async function cerrarSesion() {
    await signOut(auth);
  }

  return (
    <AuthContext.Provider
      value={{ usuarioFirebase, perfil, cargando, error, iniciarSesionConGoogle, cerrarSesion }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth debe usarse dentro de <AuthProvider>');
  return ctx;
}
